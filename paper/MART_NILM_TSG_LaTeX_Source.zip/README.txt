IEEE Transactions on Smart Grid manuscript source package

Main source file: MART_NILM_TSG.tex
Compiled manuscript: MART_NILM_TSG.pdf

This package is self-contained. It includes the IEEEtran class file, the
BibTeX database, the generated bibliography (.bbl), and all figure files.

To compile with latexmk:
  latexmk -pdf MART_NILM_TSG.tex

To compile manually:
  pdflatex MART_NILM_TSG.tex
  bibtex MART_NILM_TSG
  pdflatex MART_NILM_TSG.tex
  pdflatex MART_NILM_TSG.tex

